#pragma once
#include "Structs.h"
#include "Enums.h"

namespace TableFunctions
{
	void ChangeBet(Account& aAccount);
	void UpdateStats(Table& aTable, bool aIsWin);
	bool EvaluateTableEarnings(Table& aTable);
	void HandleBankruptcy(Account& aAccount, Table& aTable);
	int DrawRandomCard(Cards& aCards);
	bool CompareCards(int aPreviousCard, int aNewCard);
	bool IsHigherOrLowerGameOver(const Cards& aCards);
}
