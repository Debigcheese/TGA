#pragma once
#include "Structs.h"
#include "Enums.h"

namespace Games
{
	// Games logic
	void PlayGuessingRound(Account& aAccount, Table& aTable);
	void PlayOddEvenRound(Account& aAccount, Table& aTable);
	void PlaySpinWheelRound(Account& aAccount, Table& aTable);
	void PlayHigherOrLower(Account& aAccount, Table& aTable);
}
