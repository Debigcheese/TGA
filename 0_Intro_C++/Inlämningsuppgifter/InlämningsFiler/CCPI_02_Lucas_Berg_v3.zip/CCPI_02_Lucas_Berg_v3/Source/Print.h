#pragma once
#include "Structs.h"
#include "Enums.h"

namespace Print
{
	// Print to console
	void ShowIntro(const Account& aAccount);
	void ShowPersonalDetails(const Account& aAccount);
	void ShowOptions(const Table& aTable);
	void ShowRules(const Table& aTable);
	void ShowStats(const Table& aTable);
}
