#pragma once
#include "Structs.h"
#include "Enums.h"

namespace Menu
{
	void MainMenu(Account& aAccount, Table& aTable);
	void EnterTable(Account& aAccount, Table& aTable);
	void Quit();
}
