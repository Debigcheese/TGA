#include "TableFunctions.h"
#include "Print.h"
#include "Helpers.h"
#include "Games.h"
#include "Menu.h"

#include <random>
#include <iostream>

namespace TableFunctions
{
	using namespace Helpers;
	using namespace Print;
	using namespace Games;
	using namespace Menu;
	using namespace CONSTANTS;


	void ChangeBet(Account& aAccount)
	{
		std::cout << "Enter bet (1 - " << aAccount.money << "): ";
		int newBet = ReadIntInRange(1, aAccount.money);

		aAccount.bet = newBet;
		if (aAccount.bet == aAccount.money)
		{
			std::cout << "\nAll in! The guards raise an eyebrow as you push everything in...\n";
			system("pause");
		}
	}

	void HandleBankruptcy(Account& aAccount, Table& aTable)
	{
		if (aAccount.money <= 0)
		{
			std::cout << "\nYou're out of money! Security drag you out of the casino.\n";
			std::cout << "You leave with: " << aAccount.money << "kr.\n";
			aTable.currentTable = TableOption::Quit;
		}
		if (aAccount.money < aAccount.bet && aTable.currentTable != TableOption::Quit)
		{
			std::cout << "\nYour bet is higher than what is currently in your wallet!, please change bet amount.\n";
			ChangeBet(aAccount);
		}
	}

	// Table
	bool EvaluateTableEarnings(Table& aTable)
	{
		int tableIndex = TableToIndex(aTable.currentTable);
		bool wonTooMuch = false;

		if (aTable.currentTable == TableOption::Quit)
		{
			return wonTooMuch;
		}

		if (aTable.moneyArr[tableIndex] == 0) // first time
		{
			std::cout << "\nThe dealer greets you with a sly smile.\n";
		}
		else if (aTable.moneyArr[tableIndex] > EARNINGS_MAX)
		{
			std::cout
				<< "\nYou've been on fire at this table, winning far too much...\n"
				<< "The pit boss whispers to the guards, and they politely escort you away.\n"
				<< "You are no longer welcome at this table.\n";
			wonTooMuch = true;
		}
		else if (aTable.moneyArr[tableIndex] < LOSSES_MAX)
		{
			std::cout
				<< "\nThis table has not been kind to you...\n"
				<< "The dealer smirks as your losses keep piling up.\n"
				<< "Maybe it's time to try your luck somewhere else.\n";
		}
		else
		{
			std::cout
				<< "\nYour streak here has been mixed, some wins, some losses.\n"
				<< "The dealer greets you with a sly smile.\n";
		}
		system("pause");
		return wonTooMuch;
	}

	void UpdateStats(Table& aTable, bool aIsWin)
	{
		int arrIndex = 0;
		const int statArrSize = sizeof(aTable.statArr) / sizeof(int);

		int statArrTemp[statArrSize] = {};

		for (int i = 0; i < statArrSize; i++)
		{
			statArrTemp[i] = aTable.statArr[i]; //make a copy array
		}

		for (int i = 0; i < statArrSize - 1; i++)
		{
			if (aTable.statArr[0] == ResultToIndex(Result::Empty))
			{
				break; //free spot
			}
			else
			{
				aTable.statArr[i + 1] = statArrTemp[i];
				// move all indexes to the left [W][L][L][L][W] -> [0][W][L][L][L]
			}
		}

		arrIndex = 0;

		if (aIsWin)
		{
			aTable.statArr[arrIndex] = ResultToIndex(Result::Win);
		}
		else
		{
			aTable.statArr[arrIndex] = ResultToIndex(Result::Loss);
		}

		ShowStats(aTable);
	}

	bool IsHigherOrLowerGameOver(const Cards& aCards)
	{
		int countCardsLeft = 0;
		for (int card : aCards.cardsLeft)
		{
			if (card == 0)
			{
				countCardsLeft++;
			}
			if (countCardsLeft >= DECK_SIZE)
			{
				return true;
			}
		}
		return false;
	}


	//Higher or lower
	int DrawRandomCard(Cards& aCards)
	{
		std::random_device rd;
		std::mt19937 rng{rd()};
		std::uniform_int_distribution<int> dist(0, DECK_SIZE - 1);
		int randomCardIndex = 0;
		while (true)
		{
			randomCardIndex = dist(rng);

			if (aCards.cardsLeft[randomCardIndex] != 0)
			{
				aCards.cardsLeft[randomCardIndex] = 0;
				break;
			}
			if (IsHigherOrLowerGameOver(aCards))
			{
				break;
			}
		}

		return randomCardIndex;
	}

	bool CompareCards(int aPreviousCard, int aNewCard)
	{
		if (aNewCard > aPreviousCard)
		{
			return true; //is higher
		}
		else
		{
			return false; //is lower
		}
	}
}
