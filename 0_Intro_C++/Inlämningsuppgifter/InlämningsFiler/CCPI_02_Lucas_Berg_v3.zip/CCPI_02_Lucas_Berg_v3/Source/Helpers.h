#pragma once
#include "Enums.h"
#include "Structs.h"

namespace Helpers
{
	int ReadIntInRange(int aMinValue, int aMaxValue);
	int RollDice();
	int TableToIndex(const TableOption& aTable);
	int ResultToIndex(const Result& aGameResult);
}
