#include "Menu.h"
#include "Print.h"
#include "Helpers.h"
#include "Games.h"
#include "TableFunctions.h"

#include <iostream>

namespace Menu
{
	using namespace Helpers;
	using namespace Print;
	using namespace TableFunctions;
	using namespace Games;

	void MainMenu(Account& aAccount, Table& aTable)
	{
		aTable.currentTable = TableOption::Menu;

		while (aTable.currentTable == TableOption::Menu && aTable.currentTable != TableOption::Quit)
		{
			ShowPersonalDetails(aAccount);
			ShowOptions(aTable);
			HandleBankruptcy(aAccount, aTable);

			TableOption chosenTable = static_cast<TableOption>(ReadIntInRange( //reads 1-5
				static_cast<int>(TableOption::GuessingGame),
				static_cast<int>(TableOption::Quit)));

			switch (chosenTable)
			{
				case TableOption::GuessingGame:
				{
					aTable.currentTable = TableOption::GuessingGame;
					break;
				}
				case TableOption::OddOrEven:
				{
					aTable.currentTable = TableOption::OddOrEven;
					break;
				}
				case TableOption::SpinTheWheel:
				{
					aTable.currentTable = TableOption::SpinTheWheel;
					break;
				}
				case TableOption::HighOrLow:
				{
					aTable.currentTable = TableOption::HighOrLow;
					break;
				}
				case TableOption::Stats:
				{
					ShowStats(aTable);
					system("pause");
					break;
				}
				case TableOption::Quit:
				{
					std::cout << "\nYou leave with " << aAccount.money << " kr. Come back soon!\n";
					Quit();
					aTable.currentTable = TableOption::Quit;
					break;
				}
				default:
				{
					break;
				}
			}
			if (aTable.currentTable != TableOption::Quit && aTable.currentTable != TableOption::Menu)
			{
				if (!EvaluateTableEarnings(aTable))
				{
					EnterTable(aAccount, aTable);
				}
				else
				{
					aTable.currentTable = TableOption::Menu;
				}
			}
		}
	}

	void EnterTable(Account& aAccount, Table& aTable)
	{
		TableOption chosenTable = aTable.currentTable;
		while (aTable.currentTable == chosenTable && aTable.currentTable != TableOption::Quit)
		{
			ShowPersonalDetails(aAccount);
			ShowOptions(aTable);
			HandleBankruptcy(aAccount, aTable);

			GameAction action = static_cast<GameAction>(ReadIntInRange( //reads 1-4
				static_cast<int>(GameAction::Play),
				static_cast<int>(GameAction::LeaveTable)));

			switch (action)
			{
				case GameAction::Play:
				{
					switch (aTable.currentTable)
					{
						case TableOption::GuessingGame:
						{
							PlayGuessingRound(aAccount, aTable);
							break;
						}
						case TableOption::OddOrEven:
						{
							PlayOddEvenRound(aAccount, aTable);
							break;
						}
						case TableOption::SpinTheWheel:
						{
							PlaySpinWheelRound(aAccount, aTable);
							break;
						}
						case TableOption::HighOrLow:
						{
							PlayHigherOrLower(aAccount, aTable);
							break;
						}
						default:
						{
							break;
						}
					}
					HandleBankruptcy(aAccount, aTable);
					break;
				}
				case GameAction::ChangeBet:
				{
					ChangeBet(aAccount);
					break;
				}
				case GameAction::ShowRules:
				{
					ShowRules(aTable);
					break;
				}
				case GameAction::LeaveTable:
				{
					aTable.currentTable = TableOption::Menu;
					break;
				}
				default:
				{
					break;
				}
			}
		}
	}

	void Quit()
	{
		system("pause");
	}
}
