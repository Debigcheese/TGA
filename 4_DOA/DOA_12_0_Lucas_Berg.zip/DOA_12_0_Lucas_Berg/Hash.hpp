#pragma once
#include <cstdint>
#include <cstddef>
#include <string>

namespace CommonUtilities
{
	inline uint32_t JenkinsOneAtATime(const uint8_t* aData, size_t aLength)
	{
		uint32_t hash = 0;
		for (size_t i = 0; i < aLength; ++i)
		{
			hash += aData[i];
			hash += hash << 10;
			hash ^= hash >> 6;
		}
		hash += hash << 3;
		hash ^= hash >> 11;
		hash += hash << 15;
		return hash;
	}

	template <typename T>
	uint32_t Hash(T key)
	{
		return JenkinsOneAtATime(reinterpret_cast<const uint8_t*>(&key), sizeof(T));
	}

	// Specialization for std::string: hash the characters, not the
	// std::string object's bytes (which would just hash a pointer/SSO buffer).
	template <>
	inline uint32_t Hash<std::string>(std::string key)
	{
		return JenkinsOneAtATime(reinterpret_cast<const uint8_t*>(key.data()), key.size());
	}
}