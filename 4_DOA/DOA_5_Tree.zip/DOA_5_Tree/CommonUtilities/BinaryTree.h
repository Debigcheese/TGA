#pragma once

template <class T>
class BinaryTree
{
public:
	struct Node
	{
		T myValue{};
		Node* myLeft = nullptr;
		Node* myRight = nullptr;
	};

	BinaryTree();
	~BinaryTree();

	//Returnerar true om elementet finns i m�ngden, och false annars.
	bool HasElement(const T& value) const;

	//Stoppar in elementet i m�ngden, om det inte redan finns d�r. G�r 
	//ingenting annars.
	void Insert(const T& value);

	//Plockar bort elementet ur m�ngden, om det finns. G�r ingenting annars.
	void Remove(const T& value);

private:
	Node* myRoot = nullptr;
};

template <class T>
BinaryTree<T>::BinaryTree()
{
}

template <class T>
BinaryTree<T>::~BinaryTree()
{
	std::vector<Node*> nodes;

	if (myRoot)
	{
		nodes.push_back(myRoot);
	}
	while (!nodes.empty())
	{
		Node* current = nodes.front();
		nodes.pop_back();
		if (current->myLeft)
		{
			nodes.push_back(current->myLeft);
		}
		if (current->myRight)
		{
			nodes.push_back(current->myRight);
		}
		delete current;
	}
}

template <class T>
bool BinaryTree<T>::HasElement(const T& value) const
{
	auto currentNode = myRoot;

	while (currentNode && currentNode->myValue != value)
	{
		if (value < currentNode->myValue)
		{
			currentNode = currentNode->myLeft;
		}
		else if (value > currentNode->myValue)
		{
			currentNode = currentNode->myRight;
		}
	}

	return (currentNode && currentNode->myValue == value);
}

template <class T>
void BinaryTree<T>::Insert(const T& value)
{
	auto currentNode = myRoot;
	auto previousNode = currentNode;

	if (!myRoot)
	{
		Node* newNode = new Node;
		newNode->myValue = value;
		myRoot = newNode;
		return;
	}

	while (currentNode && currentNode->myValue != value)
	{
		previousNode = currentNode;

		if (value < currentNode->myValue)
		{
			currentNode = currentNode->myLeft;
		}
		else if (value > currentNode->myValue)
		{
			currentNode = currentNode->myRight;
		}
	}
	if (currentNode && currentNode->myValue == value)
	{
		return;
	}

	Node* newNode = new Node;
	if (previousNode && value < previousNode->myValue)
	{
		newNode->myValue = value;
		previousNode->myLeft = newNode;
	}
	if (previousNode && value > previousNode->myValue)
	{
		newNode->myValue = value;
		previousNode->myRight = newNode;
	}
}

//not done, need to unit test
template <class T>
void BinaryTree<T>::Remove(const T& value)
{
	auto currentNode = myRoot;
	auto previousNode = currentNode;

	while (currentNode && currentNode->myValue != value)
	{
		previousNode = currentNode;

		if (value < currentNode->myValue)
		{
			currentNode = currentNode->myLeft;
		}
		else if (value > currentNode->myValue)
		{
			currentNode = currentNode->myRight;
		}
	}

	if (previousNode == currentNode)
	{
		myRoot->myValue = 0;
		delete myRoot;
		return;
	}

	if (currentNode && currentNode->myValue == value)
	{
		if (previousNode->myValue < currentNode->myValue)
		{
			if (currentNode->myRight)
			{
				previousNode->myRight = currentNode->myRight;
			}
			else
			{
				previousNode->myRight = nullptr;
			}
		}
		if (previousNode->myValue > currentNode->myValue)
		{
			if (currentNode->myLeft)
			{
				previousNode->myLeft = currentNode->myLeft;
			}
			else
			{
				previousNode->myLeft = nullptr;
			}
		}
		delete currentNode;
	}
}

// input: 60
//              20
//       10            40
//     5   15        30  50
//    1 8 11 17
