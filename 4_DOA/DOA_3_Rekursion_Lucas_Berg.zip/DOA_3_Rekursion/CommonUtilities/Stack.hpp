#pragma once

#include <vector>
#include <cassert>

namespace CommonUtilities
{
	template <class T>
	class Stack
	{
	public:
		//Skapar en tom stack
		Stack() : myStack()
		{
		}

		//Returnerar antal element i stacken
		int GetSize() const
		{
			return (int)myStack.size();
		}

		//Returnerar det �versta elementet i stacken. Kraschar med en assert om
		//stacken �r tom.
		const T& GetTop() const
		{
			assert(!myStack.empty() && "GetTop(): stack is empty, cant access first element");
			return myStack.back();
		}

		//Returnerar det �versta elementet i stacken. Kraschar med en assert om
		//stacken �r tom.
		T& GetTop()
		{
			assert(!myStack.empty() && "GetTop(): stack is empty, cant access first element");
			return myStack.back();
		}

		//L�gger in ett nytt element �verst p� stacken
		void Push(const T& aValue)
		{
			myStack.push_back(aValue);
		}

		//Tar bort det �versta elementet fr�n stacken och returnerar det. Kraschar
		//med en assert om stacken �r tom.
		T Pop()
		{
			assert(!myStack.empty() && "Pop: stack is empty, cant access first element");
			auto target = myStack.back();
			myStack.pop_back();
			return target;
		}

	private:
		std::vector<T> myStack;
	};
}
