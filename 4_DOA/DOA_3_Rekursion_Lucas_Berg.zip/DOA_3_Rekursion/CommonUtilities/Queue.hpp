#pragma once
#include <cassert>
#include <vector>

namespace CommonUtilities
{
	template <class T>
	class Queue
	{
	public:
		//Skapar en tom k�
		Queue() : myQueue()
		{
		}

		//Returnerar antal element i k�n
		int GetSize() const
		{
			return (int)myQueue.size();
		}

		//Returnerar elementet l�ngst fram i k�n. Kraschar med en assert om k�n �r 
		//tom
		const T& GetFront() const
		{
			assert(!myQueue.empty() && "GetFront(): Cant use front if Queue is empty");
			return myQueue.front();
		}

		//Returnerar elementet l�ngst fram i k�n. Kraschar med en assert om k�n �r 
		//tom
		T& GetFront()
		{
			assert(!myQueue.empty() && "GetFront(): Cant use front if Queue is empty");
			return myQueue.front();
		}

		//L�gger in ett nytt element l�ngst bak i k�n
		void Enqueue(const T& aValue)
		{
			myQueue.push_back(aValue);
		}

		//Tar bort elementet l�ngst fram i k�n och returnerar det. Kraschar med en 
		//assert om k�n �r tom.
		T Dequeue()
		{
			assert(!myQueue.empty() && "Dequeue(): Cant use Dequeue if Queue is empty");
			auto target = myQueue.front();
			myQueue.erase(myQueue.begin());
			return target;
		}

	private:
		std::vector<T> myQueue;
	};
}
