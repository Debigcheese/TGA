#pragma once

namespace CommonUtilities
{
	template <class T>
	class DoublyLinkedList;

	template <class T>
	class DoublyLinkedListNode
	{
	public:
		// Copy-konstruktorn och assignment-operatorn �r borttagna, s� att det enda
		// s�ttet att skapa en nod �r genom att stoppa in ett v�rde i en lista.
		DoublyLinkedListNode<T>(const DoublyLinkedListNode<T>&) = delete;
		DoublyLinkedListNode<T>& operator=(const DoublyLinkedListNode<T>&) = delete;

		// Returnerar nodens v�rde
		const T& GetValue() const
		{
			return myValue;
		}

		T& GetValue()
		{
			return myValue;
		}

		// Returnerar n�sta nod i listan, eller nullptr om noden �r sist i listan
		DoublyLinkedListNode<T>* GetNext() const
		{
			return myNext;
		}

		// Returnerar f�reg�ende nod i listan, eller nullptr om noden �r f�rst i
		// listan
		DoublyLinkedListNode<T>* GetPrevious() const
		{
			return myPrevious;
		}

	private:
		// Konstruktorn och destruktorn �r privat, s� att man inte kan skapa eller
		// ta bort noder utifr�n. List-klassen �r friend, s� att den kan skapa
		// eller ta bort noder.
		friend class DoublyLinkedList<T>;

		DoublyLinkedListNode(const T& aValue)
		{
			myValue = aValue;
		}

		~DoublyLinkedListNode()
		{
			myNext = nullptr;
			myPrevious = nullptr;
		}

		T myValue;
		DoublyLinkedListNode<T>* myNext = nullptr;
		DoublyLinkedListNode<T>* myPrevious = nullptr;
	};
}
